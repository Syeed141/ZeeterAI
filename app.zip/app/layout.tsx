import type { Metadata } from "next";
import "./globals.css";
import SiteHeader from "@/components/ZeeterHeader";

export const metadata: Metadata = {
  title: "Zeeter AI",
  description: "Zeeter AI App",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body>
        <SiteHeader />

        <main className="pt-[76px] md:pt-14 lg:pt-20">{children}</main>
      </body>
    </html>
  );
}
